<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25">COPYRIGHT &copy;
            {{ date('Y') }}<a class="ms-25" href="{{url('sa1991as')}}"
                target="_blank">{{ env('APP_NAME') }}</a>
</footer>
<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
