@extends('web.layout.template')
@section('page_title', 'Home')



